/** Common helpers */
define(["angular"], function(angular) {
  "use strict";

  var mod = angular.module("common.helper", []);
  return mod;
});
